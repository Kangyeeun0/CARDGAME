﻿
// cardgameDlg.h: 헤더 파일
//

#pragma once
#define MAX_TOTAL_CARD_COUNT 10
#define MAX_PLAY_CARD_COUNT 9


// CcardgameDlg 대화 상자
class CcardgameDlg : public CDialogEx
{
private:
	
	CImage m_card_image[MAX_TOTAL_CARD_COUNT];
	char m_card_table[MAX_PLAY_CARD_COUNT*2];
	char m_state = 1; //1이면 앞면, 0이면 뒷면을 가리킴
	char m_first_index = -1;//-1이면 아직 선택한 적이 없다는 뜻으로 사용
// 생성입니다.
public:
	CcardgameDlg(CWnd* pParent = nullptr);	// 표준 생성자입니다.

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CARDGAME_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 지원입니다.


// 구현입니다.
protected:
	HICON m_hIcon;
	
	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
private:
	CProgressCtrl m_time_progress;
public:

	afx_msg void OnBnClickedHintBtn();
	afx_msg void OnBnClickedRestartBtn();
};
