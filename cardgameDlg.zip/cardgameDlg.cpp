﻿
// cardgameDlg.cpp: 구현 파일
//

#include "pch.h"
#include "framework.h"
#include "cardgame.h"
#include "cardgameDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CcardgameDlg 대화 상자



CcardgameDlg::CcardgameDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CARDGAME_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CcardgameDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS1, m_time_progress);
	
}

BEGIN_MESSAGE_MAP(CcardgameDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
//	ON_WM_CREATE()
ON_WM_LBUTTONDOWN()
ON_BN_CLICKED(IDC_HINT_BTN, &CcardgameDlg::OnBnClickedHintBtn)
ON_BN_CLICKED(IDC_RESTART_BTN, &CcardgameDlg::OnBnClickedRestartBtn)
END_MESSAGE_MAP()


// CcardgameDlg 메시지 처리기

BOOL CcardgameDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 이 대화 상자의 아이콘을 설정합니다.  응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);	
	
	// 작은 아이콘을 설정합니다.

	CString str;
	for (int i = 0; i < MAX_TOTAL_CARD_COUNT; i++) {
		str.Format(L"C:\\work\\card_image\\%03d.bmp", i);
		m_card_image[i].Load(str);
	}
	for (int i = 0; i < MAX_PLAY_CARD_COUNT; i++) {
		m_card_table[i * 2] = i;
		m_card_table[i * 2 + 1] = i;
	}
	
	// TODO: 여기에 추가 초기화 작업을 추가합니다.
	srand((unsigned int)time(NULL)); // 무작위로 카드 섞어주기
	char first, second, temp;
	for (int i = 0; i < 100; i++) {
		first = rand() % 18;
		second = rand() % 18;
		if (first != second) {
			temp = m_card_table[first];
			m_card_table[first] = m_card_table[second];
			m_card_table[second] = temp;
		}
	}
	SetTimer(1, 3000, NULL);

	m_time_progress.SetRange(0, 50); //범위를 0~120으로 설정
	m_time_progress.SetPos(50); //꽉찬 상태에서 실행
	SetTimer(2, 1000, NULL);//1초마다 범위가 줄어들도록

	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다.  문서/뷰 모델을 사용하는 MFC 애플리케이션의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

void CcardgameDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 아이콘을 그립니다.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CPaintDC dc(this);
		int index;
		for (int i = 0; i < MAX_PLAY_CARD_COUNT*2; i++) {
			if (m_card_table[i] == -1)continue;
			if (m_state == 1)
				index = m_card_table[i] + 1; //뒷면 카드는 사용하지 않기 위해 +1
			else
				index = 0;//뒷면
			m_card_image[index].Draw(dc, (i % 6) * 188, (i / 6) * 250);
		}
		//CDialogEx::OnPaint();
	}
}

// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR CcardgameDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CcardgameDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (1 == nIDEvent){//1번 타이머가 발생했을 때 실행 
		KillTimer(1);
		m_state = 0;
		for (int i = 0; i <= m_first_index; i++) { //카드 다 사라지면 성공창 띄우기
			if (m_card_table[i] == -1)
				MessageBox(L"성공", L"축하합니다!", MB_OK);
		}
		Invalidate();//대화상자를 무효화 시킴. 즉, wm_paint를 발생시키는 것과 같음
	}
	else if (nIDEvent == 2) {
		int pos = m_time_progress.GetPos();
		if (pos > 0)m_time_progress.SetPos(pos - 1);
		else {
			KillTimer(2);
			MessageBox(L"시간초과", L"실패!!", MB_OK);
		}
	}

	CDialogEx::OnTimer(nIDEvent);
}




void CcardgameDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (m_state > 0)
		return;
	int x = point.x / 188;
	int y = point.y / 250;

	if (x < 6 && y < 6) {
		int play_index = y * 6 + x;
		int index = m_card_table[play_index];

		if (m_first_index == -1)
			m_first_index = play_index;
		else if (m_first_index != play_index) {
			if (m_card_table[m_first_index] == m_card_table[play_index]) { //짝맞추기 성공했을시
				m_card_table[m_first_index] = -1; //찾았으면 카드 없애주기
				m_card_table[play_index] = -1;
			}
			m_first_index = -1;
			m_state = 2;
			SetTimer(1, 1000, NULL);
		}

		CClientDC dc(this);
		m_card_image[index + 1].Draw(dc, x * 188, y * 250);
	}
	
	CDialogEx::OnLButtonDown(nFlags, point);
}

void CcardgameDlg::OnBnClickedHintBtn()
{
	int num = GetDlgItemInt(IDC_HINT_BTN);
	if (num > 0) {
		SetDlgItemInt(IDC_HINT_BTN, num - 1);
		SetTimer(1, 2000, NULL);//2초간
		m_state = 1;//힌트로 앞면 보여줌
		Invalidate(); //WM_PAINT 메시지 유도

	}
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

}


void CcardgameDlg::OnBnClickedRestartBtn()
{

	if (IDCANCEL == MessageBox(L"게임을 재시작 하시겠습니까?", L"확인", MB_ICONQUESTION | MB_OKCANCEL))
		return;
	KillTimer(2);
	m_state = 1;
	
	for (int i = 0; i < MAX_PLAY_CARD_COUNT; i++) {
		m_card_table[i * 2] = i;
		m_card_table[i * 2 + 1] = i;
	}

	// TODO: 여기에 추가 초기화 작업을 추가합니다.
	srand((unsigned int)time(NULL)); // 무작위로 카드 섞어주기
	char first, second, temp;
	for (int i = 0; i < 100; i++) {
		first = rand() % 18;
		second = rand() % 18;
		if (first != second) {
			temp = m_card_table[first];
			m_card_table[first] = m_card_table[second];
			m_card_table[second] = temp;
		}
	}
	SetTimer(1, 3000, NULL);

	m_time_progress.SetRange(0, 120); //범위를 0~120으로 설정
	m_time_progress.SetPos(120); //꽉찬 상태에서 실행
	SetTimer(2, 1000, NULL);//1초마다 범위가 줄어들도록

	Invalidate();
	
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
